<div class="ftr-bg">
    <div class="wrap">
        <div class="footer">
        <div class="copy">
            <p class="w3-link">© All Rights Reserved | Design by&nbsp; <a href="http://w3layouts.com/"> W3Layouts</a></p>
        </div>
        <div class="clear"></div>	
    </div>
    </div>
</div>
