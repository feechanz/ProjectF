<div class="footer-bg">	
    <div class="wrap">
        <div class="footer">
            <div class="box1">
                <h4 class="btm">Mari Kita Lakukan</h4>
                <p>Memberi motivasi kepada masyarakat tentang pentingnya kesadaran dalam meningkatkan wawasan dan pendidikan untuk kemajuan bangsa dan negara.</p>
                <p>Memberi ilmu pengetahuan terutama bagi calon generasi penerus bangsa agar dapat menjadi semakin kreatif, inovatif, jujur, berintegritas, dan peduli pada sesama dan lingkungan</p>
            </div>
           <div class="box1">
                <h4 class="btm">Standar Sekolah</h4>
                <nav>
                    <ul>
                        <li><a href="">Menghasilkan generasi penerus bangsa yang prima </a></li>
                        <li><a href="">Memiliki performa yang baik dalam mendidik siswa</a></li>
                        <li><a href="">Kurikulum yang sesuai dengan keadaan dunia </a></li>
                        <li><a href="">Memiliki pengajar yang sesuai standar pemerintah</a></li>
                        <li><a href="">Menyediakan fasilitas belajar mengajar yang baik </a></li>
                        <li><a href="">Akreditasi sekolah dasar dengan peraihan nilai A </a></li>
                        <li><a href="">Mampu menghasilkan siswa yang dapat bersaing </a></li>
                    </ul>
                </nav>
            </div>
            <div class="box1">
                <h4 class="btm">Temukan Kami</h4>
                <div class="box1_address">
                    <p><?php echo $alamat;?>,</p>
                    <p><?php echo $kodepos?> <?php echo $kota;?>, <?php echo $provinsi?>,</p>
                    <p><?php echo $negara?></p>
                    <p>Phone:<?php echo $phone;?></p>
                    <p>Fax: <?php echo $fax;?></p>
                    <p>Email: <span><?php echo $email;?></span></p>
                    <p>Follow on: <span>Facebook</span>, <span>Twitter</span></p>
                </div>
            </div>
            <div class="clear"></div>			
        </div>
    </div>
</div>

