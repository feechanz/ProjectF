<!--main-->
<div class="main_btm">
<div class="wrap">
    <div class="main">
        <div class="specials">
            <div class="specials-heading">
                <h3>Latest-News</h3>
                <div class="clear"> </div>
            </div>
            <div class="box_news">
                <script type="text/javascript" src="js/paging.js"></script>
                <link rel="stylesheet" href="css/news.css">
                <table class="content_news" id="results">
                <tr>
                    <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                    <td>
                        <a href="http://www.gemscool.com/berita/read/2017/03/02/15593/finish_maintenance_2_maret_2017">
                            <h3>Finish Maintenance 2 Maret 2017</h3>
                            <p>Finish Maintenance 2 Maret 2017</p>
                        </a>
                    </td>
                    <td align="center">
                            <span></span><br>
                            <span>02-03-2017</span>
                    </td>
                </tr>
                <tr>
                    <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                    <td>
                        <a href="http://www.gemscool.com/berita/read/2017/03/01/15590/coming_soon_rank_reset_voucher">
                            <h3>Coming Soon Rank Reset Voucher</h3>
                            <p>Coming Soon Rank Reset Voucher</p>
                        </a>
                    </td>
                    <td align="center">
                        <span></span><br>
                        <span>01-03-2017</span>
                    </td>
                </tr>
                <tr>
                    <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                    <td>
                        <a href="http://www.gemscool.com/berita/read/2017/02/10/15532/pengumuman_lucky_winner_lunar_new_year_event">
                            <h3>Pengumuman Lucky Winner Lunar New Year Event</h3>
                            <p>Pengumuman Lucky Winner Lunar New Year Event</p>
                        </a>
                    </td>
                    <td align="center">
                            <span></span><br>
                            <span>10-02-2017</span>
                    </td>
                </tr>
                <tr>
                        <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2017/02/07/15521/goddess_blessed_cube_februari_2017">
                                        <h3>Goddess Blessed Cube Februari 2017</h3>
                                        <p>Goddess Blessed Cube (Periode Penjualan 08 ~ 22 Februari 2017)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>07-02-2017</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2017/02/07/15520/chocolate_full_of_love_event">
                                        <h3>Chocolate Full of Love Event</h3>
                                        <p>Chocolate Full of Love (Periode Event 08 Februari ~ 01 Maret 2017)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>07-02-2017</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2017/01/31/15491/hanbok_costume_hair_accessories">
                                        <h3>Hanbok Costume & Hair Accessories</h3>
                                        <p>Periode Penjualan Terbatas, Mulai Tanggal 01 Februari ~ 15 Februari 2017 (Pukul 07:00 WIB)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>31-01-2017</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2017/01/24/15471/lunar_new_year_event">
                                        <h3>Lunar New Year Event</h3>
                                        <p>TOS - Lunar New Year (Periode Event : 25 Januari ~ 08 Februari 2017)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>24-01-2017</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2017/01/24/15468/happy_lunar_new_year">
                                        <h3>Happy Lunar New Year</h3>
                                        <p>Happy Lunar New Year 2017</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>24-01-2017</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2017/01/24/15467/survival_instinct_event">
                                        <h3>Survival Instinct Event</h3>
                                        <p>Survival Instinct (Periode Event 25 Januari ~ 15 Februari 2017)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>24-01-2017</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2017/01/18/15456/perpanjangan_new_year_fortune_event">
                                        <h3>Perpanjangan New Year Fortune Event</h3>
                                        <p>Perpanjangan Event New Year Fortune (Periode 18 ~ 25 Januari 2017)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>18-01-2017</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2017/01/02/15408/new_goddess_blessed_cubes">
                                        <h3>New Goddess Blessed Cubes</h3>
                                        <p>New Goddess Blessed Cubes Update (Periode Penjualan 04 ~ 18 Januari 2017)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>02-01-2017</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/12/27/15400/tos_new_year_fortune_event">
                                        <h3>TOS- New Year Fortune Event</h3>
                                        <p>TOS- New Year Fortune (Periode Event 28 Desember 2016 ~ 18 Januari 2017)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>27-12-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/12/23/15387/merry_christmas_and_happy_new_year_2017">
                                        <h3>Merry Christmas And Happy New Year 2017</h3>
                                        <p>Merry Christmas And Happy New Year 2017</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>23-12-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/12/20/15371/taoist_s_secret_recipe_event">
                                        <h3>Taoist's Secret Recipe Event</h3>
                                        <p>Taoist's Secret Recipe Event</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>20-12-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/12/19/15364/rank_8_is_coming">
                                        <h3>Rank 8 Is Coming</h3>
                                        <p>Patch Note Update 21 Desember 2016</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>19-12-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/12/06/15319/tos_update_7_desember_2016">
                                        <h3>TOS Update 7 Desember 2016</h3>
                                        <p>TOS Update 7 Desember 2016</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>06-12-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/12/06/15317/giftful_season_event">
                                        <h3>Giftful Season Event</h3>
                                        <p>Giftful Season Event</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>06-12-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/12/02/15309/goddess_blessed_cube_desember_update">
                                        <h3>Goddess Blessed Cube Desember Update</h3>
                                        <p>Goddess Blessed Cube Desember Update</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>02-12-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/11/28/15287/joyfull_winter_package">
                                        <h3>Joyfull Winter Package</h3>
                                        <p>Joyfull Winter Package (Periode Penjualan : 30 November ~ 27 Desember 2016)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>28-11-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/11/21/15267/november_event_fair_2">
                                        <h3>November Event Fair 2</h3>
                                        <p>November Event Fair 2</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>21-11-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/11/21/15266/tos_update_23_november_2016">
                                        <h3>TOS Update 23 November 2016</h3>
                                        <p>TOS Update 23 November 2016</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>21-11-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/11/15/15248/tos_update_16_november_2016">
                                        <h3>TOS Update 16 November 2016</h3>
                                        <p>TOS Update 16 November 2016</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>15-11-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/11/15/15247/november_event_fair">
                                        <h3>November Event Fair</h3>
                                        <p>November Event Fair Periode Event 16 November ~ 14 Desember 2016</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>15-11-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/11/14/15243/permasalahan_reward_gvg">
                                        <h3>Permasalahan Reward GVG</h3>
                                        <p>Permasalahan Reward GVG</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>14-11-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/11/08/15216/tos_update_09_november_2016">
                                        <h3>TOS Update 09 November 2016</h3>
                                        <p>TOS Update 09 November 2016</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>08-11-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/11/01/15198/tos_november_update">
                                        <h3>TOS November Update</h3>
                                        <p>TOS November Update</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>01-11-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/10/28/15188/weekend_exp_bonus_event">
                                        <h3>Weekend EXP Bonus Event</h3>
                                        <p>Weekend EXP Bonus Event (Periode Event 29-30 Oktober 2016)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>28-10-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/10/25/15174/2nd_major_update_tos">
                                        <h3>2nd Major Update TOS</h3>
                                        <p>2nd Major Update TOS </p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>25-10-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/10/25/15172/pumpkin_and_cubes_event">
                                        <h3>Pumpkin and Cubes Event</h3>
                                        <p>Pumpkin and Cubes Event (Cooming Soon)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>25-10-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/10/18/15151/tos_oktober_update">
                                        <h3>TOS Oktober Update</h3>
                                        <p>TOS Oktober Update 19 Oktober 2016</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>18-10-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/10/18/15150/hunting_season_event">
                                        <h3>Hunting Season Event</h3>
                                        <p>Hunting Season Event (Periode Event 19 Oktober ~ 02 November 2016)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>18-10-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/10/12/15133/tos_october_halloween_package">
                                        <h3>TOS October Halloween Package</h3>
                                        <p>TOS October Halloween Package</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>12-10-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/10/11/15127/tos_october_hallooween_event">
                                        <h3>TOS October Hallooween Event</h3>
                                        <p>TOS October Hallooween Event (Periode Event 12 Oktober ~ 19 Oktober 2016)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>11-10-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/10/06/15121/daftar_pemenang_event_lesser_panda_free_gift_2">
                                        <h3>Daftar Pemenang Event Lesser Panda Free Gift 2</h3>
                                        <p>Daftar Pemenang Event Lesser Panda Free Gift 2</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>06-10-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/10/04/15105/scavenge_challenge_event">
                                        <h3>Scavenge Challenge Event</h3>
                                        <p>Scavenge Challenge Event (05~19 Oktober 2016)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>04-10-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/09/22/15068/banned_list_22_09_2016">
                                        <h3>Banned List 22/09/2016</h3>
                                        <p>Mohon laporkan segala bentuk pelanggaran melalui CS-QA Gemscool.</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>22-09-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/09/20/15059/daftar_pemenang_1st_major_update_event">
                                        <h3>Daftar Pemenang 1st Major Update Event</h3>
                                        <p>Daftar Pemenang 1st Major Update Event (periode 31 Agustus ~ 18 September 2016)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>20-09-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/09/15/15047/banned_list_15_09_2016">
                                        <h3>Banned List 15/09/2016</h3>
                                        <p>Mohon laporkan segala bentuk pelanggaran melalui CS-QA Gemscool.</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>15-09-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/09/15/15046/pemberitahuan_sanksi_pemanfaatan_bug_party">
                                        <h3>Pemberitahuan Sanksi Pemanfaatan Bug Party</h3>
                                        <p>Pemberitahuan Sanksi Pemanfaatan Bug Party</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>15-09-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/09/14/15044/tos_september_ceria_">
                                        <h3>TOS September Ceria </h3>
                                        <p>Ikuti Event TOS September Ceria periode 15 ~ 30 September 2016 dan dapatkan Special Reward Laser Panda BOX !</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>14-09-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/09/14/15041/daftar_pemenang_event_">
                                        <h3>Daftar Pemenang Event </h3>
                                        <p>Daftar Pemenang Event Idul Adha & 1st Major Update Event</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>14-09-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/09/14/15040/banned_list_14_09_2016">
                                        <h3>Banned List 14/09/2016</h3>
                                        <p>Mohon laporkan segala bentuk pelanggaran melalui CS-QA Gemscool.</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>14-09-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/09/08/15023/permintan_maaf_tree_of_savior">
                                        <h3>Permintan Maaf Tree of Savior</h3>
                                        <p>Permintan Maaf Tree of Savior mengenai permasalahan Error Reset Instant Dungeon</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>08-09-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/09/06/15010/event_hari_raya_idul_adha">
                                        <h3>Event Hari Raya Idul Adha</h3>
                                        <p>Event Menyambut Hari Raya Idul Adha 1437H bersama Tree of Savior indonesia</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>06-09-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Update-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/08/30/14985/major_update_tree_of_savior_2016">
                                        <h3>Major Update Tree of Savior 2016</h3>
                                        <p>Informasi Full Patch Update Tree of Savior Indonesia 31 Agustus 2016</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>30-08-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/08/30/14981/major_update_event_">
                                        <h3>Major Update Event !</h3>
                                        <p>Special Event menyambut Update baru Tree of Savior Indonesia!</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>30-08-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/08/26/14974/banned_list_26_08_2016">
                                        <h3>Banned List 26/08/2016</h3>
                                        <p>Mohon laporkan segala bentuk pelanggaran melalui CS-QA Gemscool.</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>26-08-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/08/24/14966/banned_list_24_08_2016">
                                        <h3>Banned List 24/08/2016</h3>
                                        <p>Mohon laporkan segala bentuk pelanggaran melalui CS-QA Gemscool.</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>24-08-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/08/19/14949/banned_list_19_08_2016">
                                        <h3>Banned List 19/08/2016</h3>
                                        <p>Banned List Permanen ToS tanggal 19 Agustus 2016  Total = 750</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>19-08-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/08/03/14898/banned_list_3_08_2016">
                                        <h3>Banned List 3/08/2016</h3>
                                        <p>Banned List 3/08/2016</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>03-08-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/08/02/14892/agustus_duel_competition_event">
                                        <h3>Agustus Duel Competition Event</h3>
                                        <p>Agustus Duel Competition Event</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>02-08-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/08/02/14888/agustusan_bersama_tos">
                                        <h3>Agustusan Bersama TOS</h3>
                                        <p>Agustusan Bersama TOS Event (Periode 03 ~ 31 Agustus 2016)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>02-08-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/08/02/14887/banned_list_2_08_2016">
                                        <h3>Banned List 2/08/2016</h3>
                                        <p>Banned List 2/08/2016</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>02-08-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/08/01/14884/pemenang_semangat_savior_event_">
                                        <h3>Pemenang Semangat Savior Event.</h3>
                                        <p>Daftar Pemenang Semangat Savior (Welcome Back Savior, Newbie Recruitment Event)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>01-08-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/08/01/14881/tos_supporting_event">
                                        <h3>ToS Supporting Event</h3>
                                        <p>ToS Supporting Event (1 Agustus ~ 31 Agustus 2016)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>01-08-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/07/29/14877/pemenang_event_2nd_friend_s_referal">
                                        <h3>Pemenang Event 2nd Friend's Referal</h3>
                                        <p>Pemenang Event 2nd Friend's Referal</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>29-07-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/07/26/14852/banned_list_25_07_2016">
                                        <h3>Banned List 25/07/2016</h3>
                                        <p>Banned List 25/07/2016</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>26-07-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/07/21/14847/mol_xplor_tree_of_savior">
                                        <h3>MOL XPLOR Tree of Savior</h3>
                                        <p>MOL XPLOR Tree of Savior</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>21-07-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/07/19/14834/banned_list_19_07_2016">
                                        <h3>Banned List 19/07/2016</h3>
                                        <p>Banned List 19/07/2016</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>19-07-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/07/14/14824/semangat_savior_event">
                                        <h3>Semangat Savior Event</h3>
                                        <p>Semangat Savior Event</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>14-07-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/07/13/14810/_finish_maintenance_13_juli_2016_selesai_">
                                        <h3>[Finish] Maintenance 13 Juli 2016 Selesai !</h3>
                                        <p>Maintenance Server TOS 13 Juli 2016 telah Selesai !</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>13-07-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/07/12/14803/_pemenang_beginning_of_savior_event">
                                        <h3>[Pemenang] Beginning of Savior Event</h3>
                                        <p>[Pemenang] Beginning of Savior Event</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>12-07-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/07/12/14801/perbaikan_permasalahan_tos_indonesia">
                                        <h3>Perbaikan Permasalahan TOS Indonesia</h3>
                                        <p>Official Announcement (Team Manager) TOS Indonesia</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>12-07-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/07/11/14796/banned_list_11_07_2016">
                                        <h3>Banned List 11/07/2016</h3>
                                        <p>Banned List 11/07/2016</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>11-07-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/07/05/14792/selamat_hari_raya_idul_fitri_1437_h">
                                        <h3>Selamat Hari Raya Idul Fitri 1437 H</h3>
                                        <p>Selamat Hari Raya Idul Fitri 1437 H</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>05-07-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/07/05/14788/finish_maintenance_server_">
                                        <h3>Finish Maintenance Server </h3>
                                        <p>Maintenance Server 05 Juli 2016 telah selesai.</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>05-07-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/07/01/14774/lebaran_big_sale_event">
                                        <h3>Lebaran Big Sale Event</h3>
                                        <p>Dapatkan Penawaran Fantastik Selama Lebaran Big Sale Event (Periode 01 Juli ~ 11 Juli 2016)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>01-07-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/06/30/14772/tos_lebaran_event">
                                        <h3>TOS Lebaran Event</h3>
                                        <p>Sambut Suasana Lebaran Idul Fitri bersama Tree of Savior</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>30-06-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/06/29/14760/_solusi_error_automatch_dungeon_dan_pvp">
                                        <h3>[Solusi]Error Automatch Dungeon dan PVP</h3>
                                        <p>[Solusi]Error Automatch Dungeon dan PVP</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>29-06-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/06/27/14739/permintaan_maaf_event">
                                        <h3>Permintaan Maaf & Event</h3>
                                        <p>Permohonan Maaf dari Tree of Savior INA</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>27-06-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/06/24/14735/big_update_tree_of_savior_indonesia">
                                        <h3>Big Update Tree of Savior Indonesia</h3>
                                        <p>Full Patch pada Big Update Tree of Savior Indonesia Tanggal 29 Juni 2016</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>24-06-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/06/22/14723/friends_referal_event">
                                        <h3>Friends Referal Event</h3>
                                        <p>Ajak Teman kamu bermain TOS dan Raih berbagai hadiah dalam Friends Referal Event (22 Juni ~ 17 Juli 2016)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>22-06-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/06/22/14719/winner_friends_of_savior">
                                        <h3>winner friends of savior</h3>
                                        <p>winner friends of savior</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>22-06-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/06/21/14709/winner_warnet_of_savior_event">
                                        <h3>Winner Warnet of Savior Event</h3>
                                        <p>Winner Warnet of Savior Event</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>21-06-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/06/18/14698/tos_campus_attack_event">
                                        <h3>TOS Campus Attack Event</h3>
                                        <p>Ikutilah TOS Campus Attack Event di 12 Kampus Jakarta & Depok pada periode 16~22 Juni 206</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>18-06-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/06/17/14695/paket_ramadhan_tree_of_savior">
                                        <h3>Paket Ramadhan Tree of Savior</h3>
                                        <p>Dapatkan promo menarik dalam Paket Ramadhan Event</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>17-06-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/06/14/14684/obt_tos_facebook_instagram_event">
                                        <h3>OBT TOS Facebook & Instagram Event</h3>
                                        <p>OBT TOS Facebook & Instagram Event (Periode 14 Juni ~ 13 Juli 2016) Info Selengkapnya</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>14-06-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/06/10/14665/bukber_tree_of_savior_event">
                                        <h3>Bukber Tree of Savior Event</h3>
                                        <p>Bukber Tree of Savior Event (Periode 10 Juni ~ 03 Juli 2016)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>10-06-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/06/01/14610/server_obt_resmi_dibuka_">
                                        <h3>Server OBT Resmi Dibuka !!!</h3>
                                        <p>Server OBT Tree of Savior Indonesia telah dibuka! Selamat Bermain Savior ^o^</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>01-06-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/06/01/14606/pengumuman_obt_tos">
                                        <h3>Pengumuman OBT ToS</h3>
                                        <p>Pengumuman OBT ToS</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>01-06-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/05/31/14604/laporan_dvd_rusak">
                                        <h3>Laporan DVD Rusak</h3>
                                        <p>Laporan DVD Rusak</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>31-05-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/05/31/14598/pemenang_nostalgia_gamer_event">
                                        <h3>Pemenang Nostalgia Gamer Event</h3>
                                        <p>Informasi Pemenang Nostalgia Gamer Event tersedia pada link berikut ini, Baca selengkapnya :</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>31-05-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/05/30/14595/beginning_of_savior_event">
                                        <h3>Beginning of Savior Event</h3>
                                        <p>Beginning of Savior Event (OBT EVENT)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>30-05-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/05/26/14583/tos_point_tp_">
                                        <h3>TOS Point [TP]</h3>
                                        <p>Penggunaan TOS Point [TP]</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>26-05-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/05/24/14566/obt_cash_item_sale">
                                        <h3>OBT Cash Item Sale</h3>
                                        <p>OBT Cash Item Sale (Periode Event : 24 Mei 2016 ~ 29 Mei 2016)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>24-05-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/05/20/14562/manual_patch_update_20_mei_2016">
                                        <h3>Manual Patch Update 20 Mei 2016</h3>
                                        <p>Info Update TOS Manual Patch 20 Mei 2016</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>20-05-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/ETC-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/05/19/14556/tos_twibbon_campaign">
                                        <h3>ToS Twibbon Campaign</h3>
                                        <p>ToS Twibbon Campaign</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>19-05-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/05/19/14552/pemberitahuan_friends_of_savior_event">
                                        <h3>Pemberitahuan Friends of Savior Event</h3>
                                        <p>Pemberitahuan Pemilihan Server "Open Beta Celebration Event"</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>19-05-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/05/18/14549/tos_open_beta_celebration_event">
                                        <h3>TOS Open Beta Celebration Event</h3>
                                        <p>TOS Open Beta Celebration Event [Periode 18 Mei ~ 03 Juni 2016]</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>18-05-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/05/18/14548/warnet_of_savior_event">
                                        <h3>Warnet of Savior Event</h3>
                                        <p>Warnet of Savior Event (Periode 18 Mei ~ 12 Juni 2016) </p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>18-05-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/05/11/14510/dvd_order_">
                                        <h3>DVD Order!</h3>
                                        <p>Pemesanan DVD Tree of Savior Indonesia telah dibuka!</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>11-05-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/05/02/14455/fan_art_contest_event">
                                        <h3>Fan Art Contest Event</h3>
                                        <p>[EVENT] Tree Of Savior - Fan Art Contest</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>02-05-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/04/29/14438/pemenang_event_cbt_2_tree_of_savior_ina">
                                        <h3>Pemenang Event CBT 2 Tree of Savior INA</h3>
                                        <p>Pemenang Event CBT 2 Tree of Savior INA</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>29-04-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/04/15/14370/come_create_get_the_g_cash_">
                                        <h3>Come, Create & Get The G-Cash!</h3>
                                        <p>Come, Create & Get The G-Cash (16~21 April 2016)</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>15-04-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/03/28/14273/_2nd_cbt_facebook_instagram_event">
                                        <h3>[2nd CBT] Facebook & Instagram Event</h3>
                                        <p>Sosial Media Event! Special menyambut CBT2 ToS Indonesia (8 - 20 April 2016)!</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>28-03-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/03/28/14271/_2nd_cbt_lucky_warnet_event">
                                        <h3>[2nd CBT] Lucky Warnet Event</h3>
                                        <p>Ikuti Special Event 2nd CBT TOS untuk Operator dan Warnet Owner !!!</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>28-03-2016</span>
                        </td>
                </tr>
                                                                                                <tr>
                        <td class="type-news text-center"><img src="images/Notice-Icon.png"></td>
                        <td>
                                <a href="http://www.gemscool.com/berita/read/2016/03/28/14270/peraturan_dan_ketentuan_tree_of_savior_indonesia">
                                        <h3>Peraturan dan Ketentuan Tree of savior Indonesia</h3>
                                        <p>Peraturan dan Ketentuan Tree of savior Indonesia</p>
                                </a>
                        </td>
                        <td align="center">
                                <span></span><br>
                                <span>28-03-2016</span>
                        </td>
                </tr>
                <tr>
                    <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                    <td>
                            <a href="http://www.gemscool.com/berita/read/2016/03/28/14269/_2nd_cbt_bug_finder_best_adventure_event">
                                    <h3>[2nd CBT] Bug Finder & Best Adventure Event</h3>
                                    <p>Ikuti CBT2 ToS Indonesia, Jadilah yang terbaik dan temukan bugs atau errornya untuk mendapatkan Hadiah Istimewa!</p>
                            </a>
                    </td>
                    <td align="center">
                            <span></span><br>
                            <span>28-03-2016</span>
                    </td>
                </tr>
                                                                                                <tr>
                    <td class="type-news text-center"><img src="images/Event-Icon.png"></td>
                    <td>
                        <a href="http://www.gemscool.com/berita/read/2016/03/28/14268/_2nd_cbt_pre_character_creation_event">
                                <h3>[2nd CBT] Pre-Character Creation Event</h3>
                                <p>Buat Karakter sebelum CBT2 Dimulai dan Raih Item Edisi Khusus!</p>
                        </a>
                    </td>
                    <td align="center">
                        <span></span><br>
                        <span>28-03-2016</span>
                    </td>
                </tr>
            </table>
            <div class="pagination_box" style="margin-bottom: 500px;">
                <div id="pageNavPosition"></div>
            </div>
            <script type="text/javascript">
            var pager = new Pager('results', 4); 
            pager.init(); 
            pager.showPageNav('pager', 'pageNavPosition'); 
            pager.showPage(1);
            </script>
        </div>
            <br>
            <br>
        <div class="clear"> </div>
        </div>
        
    </div>
</div>
</div>