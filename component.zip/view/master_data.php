<div class="col span_2_of_4">
    <h2 class="style" align ="center"><a href="index.php?page=lesson">Data Mata Pelajaran</a></h1>
    <h2 class="style" align ="center"><a href="index.php?page=teacher">Data Guru</a></h1>
    <h2 class="style" align ="center"><a href="index.php?page=student">Data Siswa</a></h1>
    <h2 class="style" align ="center"><a href="index.php?page=new_student">Data Calon Siswa Baru</a></h1>
    <h2 class="style" align ="center"><a href="index.php?page=kelas">Data Kelas</a></h1>
    
</div>