<div class="col span_2_of_4">
    <h2 class="style" align ="center"><a href="index.php?page=bobot_beasiswa">Penentuan Bobot Beasiswa</a></h1>
    <h2 class="style" align ="center"><a href="index.php?page=calon_beasiswa">Calon Beasiswa</a></h1>
</div>