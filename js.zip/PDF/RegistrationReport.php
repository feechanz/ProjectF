<?php
require 'pdfcrowd.php';

// create an API client instance
$client = new Pdfcrowd("feechan", "b5b69f1ae3ba902a429ef59c7037cd9a");

// convert a web page and store the generated PDF into a variable
$content = "<body <h1 align='center'>My HTML Layout</h1></body>";
$pdf = $client->convertHtml($content);

// set HTTP response headers
header("Content-Type: application/pdf");
header("Cache-Control: max-age=0");
header("Accept-Ranges: none");
//header("Content-Disposition: attachment; filename=\"google_com.pdf\"");
//


echo $pdf;
?>