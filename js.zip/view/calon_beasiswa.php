<div class="col span_2_of_4">
    <h2 class="style" align ="center"><a href="index.php?page=class_beasiswa&classlevel=1">Siswa Kelas 1</a></h1>
    <h2 class="style" align ="center"><a href="index.php?page=class_beasiswa&classlevel=2">Siswa Kelas 2</a></h1>
    <h2 class="style" align ="center"><a href="index.php?page=class_beasiswa&classlevel=3">Siswa Kelas 3</a></h1>
    <h2 class="style" align ="center"><a href="index.php?page=class_beasiswa&classlevel=4">Siswa Kelas 4</a></h1>
    <h2 class="style" align ="center"><a href="index.php?page=class_beasiswa&classlevel=5">Siswa Kelas 5</a></h1>
    <h2 class="style" align ="center"><a href="index.php?page=class_beasiswa&classlevel=6">Siswa Kelas 6</a></h1>
</div>