<div class="col span_2_of_4">
    <h2 class="style" align ="center">Maaf!</h1>
    <h2 class="style" align ="center">Pendaftaran saat ini sedang tidak dibuka!</h1>
    <h2 align="center"><img src="images/sorry.png" title="image-name" width="30%" height="30%"></h2>
</div>