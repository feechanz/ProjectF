<div class="btm_border">
    <div class="h_bg">
        <div class="wrap">
            <div class="header">
                <div class="logo">
                    <h1><a href="index.php">
                            <img src="images/logo.png" alt="">
                        </a>
                    </h1>
                </div>
                <?php
                    include_once 'social_menu.php';
                ?>
                <div class="clear"></div>
            </div>
            <div class='h_btm'>
                <?php
                    include_once 'menu.php';
                ?>
                <div class="search">
                    <form>
                        <input type="text" value="">
                        <input type="submit" value="">
                    </form>
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
</div>