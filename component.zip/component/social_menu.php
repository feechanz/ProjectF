 <div class="social-icons">
    <ul>
        <li>
            <a class="facebook" href="#" target="_blank"></a>
        </li>
        <li>
            <a class="twitter" href="#" target="_blank"></a>
        </li>
        <li>
            <a class="googleplus" href="#" target="_blank"></a>
        </li>
        <li>
            <a class="dribbble" href="#" target="_blank"></a>
        </li>
        <li>
            <a class="vimeo" href="#" target="_blank"></a>
        </li>
   </ul>
</div>	