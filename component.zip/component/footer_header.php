<div class="footer-bg">	
    <div class="wrap">
        <div class="footer">
            <div class="box1">
                <h4 class="btm">What We Do</h4>
                <p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. ions from the 1914 below for those  by H. Rackham</p>
                <p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those The standard chunk of Lorem Ipsum used since the 1500s is reproduced reproduced</p>
            </div>
           <div class="box1">
                <h4 class="btm">Categories</h4>
                <nav>
                    <ul>
                        <li><a href="">The standard chunk of Lorem Ipsum used since </a></li>
                        <li><a href="">Duis a augue ac libero euismod viverra sitth</a></li>
                        <li><a href="">Duis a augue ac libero euismod viverra sit </a></li>
                        <li><a href="">The standard chunk of Lorem Ipsum used since </a></li>
                        <li><a href="">Duis a augue ac libero euismod viverra sit </a></li>
                        <li><a href="">The standard chunk of Lorem Ipsum used since </a></li>
                        <li><a href="">Duis a augue ac libero euismod viverra sit </a></li>
                    </ul>
                </nav>
            </div>
            <div class="box1">
                <h4 class="btm">Temukan Kami</h4>
                <div class="box1_address">
                    <p><?php echo $alamat;?>,</p>
                    <p><?php echo $kodepos?> <?php echo $kota;?>, <?php echo $provinsi?>,</p>
                    <p><?php echo $negara?></p>
                    <p>Phone:<?php echo $phone;?></p>
                    <p>Fax: <?php echo $fax;?></p>
                    <p>Email: <span><?php echo $email;?></span></p>
                    <p>Follow on: <span>Facebook</span>, <span>Twitter</span></p>
                </div>
            </div>
            <div class="clear"></div>			
        </div>
    </div>
</div>

