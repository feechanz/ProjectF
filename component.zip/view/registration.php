<!--main-->
<div class="main_btm">
    <div class="wrap">
        <div class="main">
            <div class="contact">
                <div class="section group">				
                   		
                    <div class="col span_2_of_4">
                        <div class="registration-form">
                            <h2 class="style">IDENTITAS PESERTA DIDIK (WAJIB DI ISI)</h2>
                            <form method="post" action="">
                                <div>
                                    <span><label>Nama Lengkap</label></span>
                                    <span><input name="name" type="text" class="textbox"></span>
                                </div>
                                <div>
                                    <span><label>Jenis Kelamin</label></span>
                                    <span>
                                        <select name="gender">
                                            <option value="male">Pria</option>
                                            <option value="female">Wanita</option>
                                        </select>
                                        
                                    </span>
                                </div>
                                <div>
                                    <span><label>Tempat Lahir</label></span>
                                    <span><input name="email" type="text" class="textbox"></span>
                                </div>
                                <div>
                                    <span><label>Tanggal Lahir</label></span>
                                    <span><input name="email" type="date" class="textbox"></span>
                                </div>
                                <div>
                                    <span><label>Agama</label></span>
                                    <span>
                                        <select name="religion">
                                            <option value="islam">Islam</option>
                                            <option value="protestan">Protestan</option>
                                            <option value="katolik">Katolik</option>
                                            <option value="hindu">Hindu</option>
                                            <option value="konghucu">Konghucu</option>
                                        </select>
                                        
                                    </span>
                                </div>
                                <div>
                                    <span><label>Berkebutuhan Khusus</label></span>
                                    <span><input name="email" type="text" class="textbox"></span>
                                </div>
                                <div>
                                    <span><label>Alat transportasi ke sekolah</label></span>
                                    <span><input name="name" type="text" class="textbox"></span>
                                </div>
                                <div>
                                    <span><label>Jenis Tinggal</label></span>
                                    <select name="stay">
                                        <option value="islam">Bersama Orang Tua</option>
                                        <option value="protestan">Bersama Wali</option>
                                        <option value="katolik">Tinggal Sendiri / Kost</option>
                                    </select>
                                </div>
                                <div>
                                    <span><label>Nomor Telephone</label></span>
                                    <span><input name="phone" type="text" class="textbox"></span>
                                </div>
        
                                <div>
                                    <span><label>E-Mail</label></span>
                                    <span><input name="email" type="text" class="textbox"></span>
                                </div>
                                
                                <h2 class="style">DATA DIRI ORANG TUA WALI (WAJIB DI ISI)</h2>
                                 
                                <div>
                                    <span><label>Nama Ayah</label></span>
                                    <span><input name="email" type="text" class="textbox"></span>
                                </div>
                                <div>
                                    <span><label>Tahun Lahir</label></span>
                                    <span><input name="phone" type="text" class="textbox"></span>
                                </div>
                                 <div>
                                    <span><label>Pekerjaan</label></span>
                                    <span><input name="name" type="text" class="textbox"></span>
                                </div>
                                <div>
                                    <span><label>Pendidikan</label></span>
                                    <span>
                                        <select name="religion">
                                            <option value="sd">SD</option>
                                            <option value="smp">SMP</option>
                                            <option value="sma">SMA</option>
                                            <option value="sarjana">Sarjana</option>
                                            <option value="magister">Magister</option>
                                            <option value="profesor">Profesor</option>
                                        </select>
                                        
                                    </span>
                                </div>
                                <div>
                                    <span><label>Penghasilan Bulanan</label></span>
                                    <span><input name="email" type="text" class="textbox"></span>
                                </div>
                                <div>
                                    <span><label>Nama Ibu</label></span>
                                    <span><input name="email" type="text" class="textbox"></span>
                                </div>
                                <div>
                                    <span><label>Tahun Lahir</label></span>
                                    <span><input name="phone" type="text" class="textbox"></span>
                                </div>
                                 <div>
                                    <span><label>Pekerjaan</label></span>
                                    <span><input name="name" type="text" class="textbox"></span>
                                </div>
                                <div>
                                    <span><label>Pendidikan</label></span>
                                    <span>
                                        <select name="religion">
                                            <option value="sd">SD</option>
                                            <option value="smp">SMP</option>
                                            <option value="sma">SMA</option>
                                            <option value="sarjana">Sarjana</option>
                                            <option value="magister">Magister</option>
                                            <option value="profesor">Profesor</option>
                                        </select>
                                        
                                    </span>
                                </div>
                                <div>
                                    <span><label>Penghasilan Bulanan</label></span>
                                    <span><input name="email" type="text" class="textbox"></span>
                                </div>
                                
                                <h2 class="style">DATA PERIODIK (WAJIB DI ISI)</h2>
                                 
                                <div>
                                    <span><label>Tinggi Badan</label></span>
                                    <span><input name="email" type="text" class="textbox" style="width: 20%" placeholder="Cm"></span>
                                </div>
                                 <div>
                                    <span><label>Berat Badan</label></span>
                                    <span><input name="email" type="text" class="textbox" style="width: 20%" placeholder="Kg"></span>
                                </div>
                                 <div>
                                    <span><label>Jarak Tempat Tinggal Ke Sekolah</label></span>
                                    <span><input name="email" type="text" class="textbox" style="width: 20%;" placeholder="Km"></span>
                                </div>
                                 <div>
                                    <span><label>Waktu Tempuh Berangkat Ke Sekolah</label></span>
                                    <span><input name="email" type="text" class="textbox" style="width: 20%"> </span>
                                </div>
                                 <div>
                                    <span><label>Jumlah Saudara Kandung</label></span>
                                    <span><input name="email" type="number" class="textbox" style="width: 5%"></span>
                                </div>
                                <div>
                                    <span><input type="submit" value="Apply"></span>
                                </div>
                            </form>
                          </div>
                    </div>		
                    <div class="clear"></div>
                </div>
            </div>
        </div>
    </div>
</div>