<div class="footer-bg">	
    <div class="wrap">
        <div class="footer">
            <div class="box1">
                <h4 class="btm">What We Do</h4>
                <p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. ions from the 1914 below for those  by H. Rackham</p>
                <p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those The standard chunk of Lorem Ipsum used since the 1500s is reproduced reproduced</p>
            </div>
           <div class="box1">
                <h4 class="btm">Categories</h4>
                <nav>
                    <ul>
                        <li><a href="">The standard chunk of Lorem Ipsum used since </a></li>
                        <li><a href="">Duis a augue ac libero euismod viverra sitth</a></li>
                        <li><a href="">Duis a augue ac libero euismod viverra sit </a></li>
                        <li><a href="">The standard chunk of Lorem Ipsum used since </a></li>
                        <li><a href="">Duis a augue ac libero euismod viverra sit </a></li>
                        <li><a href="">The standard chunk of Lorem Ipsum used since </a></li>
                        <li><a href="">Duis a augue ac libero euismod viverra sit </a></li>
                    </ul>
                </nav>
            </div>
            <div class="box1">
                <h4 class="btm">Get in touch</h4>
                <div class="box1_address">
                    <p>500 Lorem Ipsum Dolor Sit,</p>
                    <p>22-56-2-9 Sit Amet, Lorem,</p>
                    <p>USA</p>
                    <p>Phone:(00) 222 666 444</p>
                    <p>Fax: (000) 000 00 00 0</p>
                    <p>Email: <span>info(at)mycompany.com</span></p>
                    <p>Follow on: <span>Facebook</span>, <span>Twitter</span></p>
                </div>
            </div>
            <div class="clear"></div>			
        </div>
    </div>
</div>

