<div class="col span_2_of_4">
    <h2 class="style" align ="center">Terima kasih!</h1>
    <h2 class="style" align ="center">Pendaftaran anda telah selesai!</h1>
    <h2 align="center"><img src="images/thankyou.png" title="image-name" width="30%" height="30%"></h2>
</div>